from flask import Flask, request, render_template, url_for
app = Flask(__name__)


def sum(x, y):
    return x+y


def sub(x, y):
    return x-y


def mul(x, y):
    return x*y


def div(x, y):
    return int(x/y)


@app.route('/')
def fun():
    return render_template('cal.html')


@app.route('/calculate', methods=['POST', 'GET'])
def send():

    if request.method == "POST":
        data = request.form
        number = 0
        op = ''
        sum = 0
        i = data['y']
        l = []
        for x in i:
            l.append(x)
        flag = True
        j = 0
        for x in l:
            j += 1
            if x.isdigit():
                number = 10 * number + int(x)
                if flag == False:
                    if l[j+1] == '=':
                        if op == '+':
                            sum = sum + number
                        elif op == '-':
                                sum = sum - number
                        elif op == '*':
                            sum = sum * number
                        elif op == '/':
                            sum = int(sum / number)
            
            else:
                if not(x==','):
                    if not(op == ''):
                        if not(flag):    
                            if x == '+':
                                op='+'
                                sum = sum + number
                                number = 0
                            elif x == '-':
                                op='-'
                                sum = sum - number
                                number = 0
                            elif x == '*':
                                op='*'
                                sum = sum * number
                                number = 0
                            elif x == '/':
                                op='/'
                                sum = int(sum / number)
                                number = 0
                            elif x == '=':
                                return str(sum)
                        else:
                            if op == '+':
                                sum = sum + number
                                number = 0
                                flag=False
                            elif op == '-':
                                sum = sum - number
                                number = 0
                                flag=False
                            elif op == '*':
                                sum = sum * number
                                number = 0
                                flag=False
                            elif op == '/':
                                sum = int(sum / number)
                                number = 0
                                flag=False
                            if x == '=':
                                return str(sum)    
                    else:
                        if not(x == '='):
                            op=x
                            sum = number
                            number = 0


if __name__ == "__main__":
    app.run(debug=True)