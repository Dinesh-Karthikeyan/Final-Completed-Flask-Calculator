const inputs = { y: [] };
var num = 0;

function fun(x) {
    var httpRequest;

    if (!(x == 'clear')) {
        inputs.y.push(x);
    }

    if (!isNaN(x)) {
        num = 10 * num + parseInt(x);
        document.getElementById('display').value = num;
    }

    else {
        num = 0;
        if (x == '+' || x == "*" || x == '/' || x == '-') {
            document.getElementById('display').value = x;
            if (x == '*') {
                document.getElementById('display').value = 'x';
            }
        }
        else {
            if (x == 'clear') {
                num = 0;
                document.getElementById('display').value = 0;
            }
        }
    }


    if (x === '=') {
        httpRequest = new XMLHttpRequest();

        if (!httpRequest) {
            alert('Giving up :( Cannot create an XMLHTTP instance');
            return false;
        }

        httpRequest.onreadystatechange = takeAnswer;
        var urlEncodeData = '',
            urlEncodeDataPairs = [],
            name;
        for (name in inputs) {
            urlEncodeDataPairs.push(encodeURIComponent(name) + '=' + encodeURIComponent(inputs[name]));
        }
        urlEncodeData = urlEncodeDataPairs.join('&').replace(/%20/g, '+');
        httpRequest.open('POST', '/calculate');
        httpRequest.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        httpRequest.send(urlEncodeData);

        function takeAnswer() {
            if (httpRequest.readyState == 4) {

                if (httpRequest.status === 200) {
                    var output = httpRequest.responseText;
                    
                    document.getElementById('display').value = output;
                    num = 0;
                    inputs.y = [];
                }
                else{
                alert("There has been an issue");
                }
            }
        }
    }

}